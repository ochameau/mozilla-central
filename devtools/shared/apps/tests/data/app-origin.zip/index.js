window.addEventListener("message", function (event) {
  var evt = new CustomEvent("response", {detail:event.data});
  window.dispatchEvent(evt);
});
